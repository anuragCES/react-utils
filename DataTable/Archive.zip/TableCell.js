import React, { Component, PropTypes } from 'react'
import { tableCell } from './styles'

export default class TableCell extends Component {
  render () {
    const { flexBase, type, children, style, onClick } = this.props

    return (
      <li style={tableCell({flexBase, type, style})} onClick={onClick}>
        <div style={{flex: '1 1 auto', flexWrap: 'wrap'}}>{children}</div>
      </li>
    )
  }
}

TableCell.propTypes = {
  flexBase: PropTypes.oneOfType([
    PropTypes.string.isRequired,
    PropTypes.number.isRequired,
  ]),
  children: PropTypes.any,
  type: PropTypes.string,
  header: PropTypes.bool,
  style: PropTypes.object,
  onClick: PropTypes.func,
}

TableCell.defaultProps = {
  header: false,
  style: {},
  onClick: () => {},
}
