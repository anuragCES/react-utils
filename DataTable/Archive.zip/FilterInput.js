import React, { Component, PropTypes } from 'react'
import _ from 'lodash'
import { nAf } from 'utils'

export default class FilterInput extends Component {

  constructor ({value}) {
    super()

    this.state = {
      value,
      _isMounted: false,
    }

    this.onChange = this.onChange.bind(this)
    this.onFocus = this.onFocus.bind(this)
    this.setRef = this.setRef.bind(this)
  }

  componentWillReceiveProps ({value}) {
    if (value !== this.state.value) {
      this.setState({value})
    }
  }

  componentDidMount () {
    const { focus } = this.props

    if (focus && this.inputRef) {
      this.inputRef.focus()
    }

    this.setState({
      _isMounted: true,
    })

    this.propagateChange = _.debounce(this.propagateChange, 250)
  }

  setRef (_ref) {
    if (_ref) {
      this.inputRef = _ref
    }
  }

  onChange ({target}) {
    const { value } = target
    this.setState({value})
    this.propagateChange(value)
  }

  onFocus () {
    const { _isMounted } = this.state

    if (_isMounted) {
      this.props.onFocus()
    }
  }

  propagateChange (value) {
    this.props.onChange(value)
  }

  render () {
    const { placeholder, align, hidePlaceholder } = this.props
    const { value } = this.state
    return (
      <input ref={this.setRef}
        type='text'
        style={{
          width: '100%',
          border: 0,
          padding: 7,
          outline: 'none',
          backgroundColor: 'transparent',
          opacity: 0.8,
          fontWeight: '400',
          textAlign: align,
        }}
        value={value || ''}
        placeholder={hidePlaceholder ? '' : placeholder}
        onChange={this.onChange}
        onFocus={this.onFocus}
      />
    )
  }
}

FilterInput.propTypes = {
  value: PropTypes.any,
  onChange: PropTypes.func.isRequired,
  onFocus: PropTypes.func.isRequired,
  align: PropTypes.oneOf(['left', 'right']),
  placeholder: PropTypes.string,
  focus: PropTypes.bool,
  hidePlaceholder: PropTypes.bool,
}

FilterInput.defaultProps = {
  align: 'left',
  placeholder: '',
  focus: false,
  onFocus: nAf,
}
