// Libs
import React, { Component, PropTypes } from 'react'
import _ from 'lodash'

// Styles
import { fonts, shadow, flex, colors } from 'styles'
import {
  filterCell,
  filtersInput,
} from './styles'

// Components
import TableRow from './TableRow'
import TableCell from './TableCell'
import FilterInput from './FilterInput'
import { CheckBox } from 'components/forms'
import {
  NavBeforeIcon, NavAfterIcon,
  NavFirstIcon, NavLastIcon,
  UpIcon, DownIcon,
} from 'components/icons'
import InfoButton from './InfoButton'

// Utils
import { translate, translate2, createServices } from 'utils'
import { defineMessages } from 'react-intl'

// Hocs
import responsive from 'hocs/responsive'

// Local
const ASC = 'asc'
const DESC = 'desc'
const PROP_UNAVAILABLE = 'PROP_UNAVAILABLE'

const messages = defineMessages({
  filterText: {
    id: 'filterText',
    description: 'filterText',
    defaultMessage: 'Table is currently being filtered.',
  },
  clearFilterText: {
    id: 'clearFilterText',
    description: 'clearFilterText',
    defaultMessage: 'Clear all filters.',
  },
})

// Exports
export class DataTable extends Component {
  constructor ({columns, service, mediaQueryMatch, selectedRecords, records, filters, clearFilter}) {
    super()

    this.state = {
      page: 0,
      allSelected: false,
      selectedRecords: _.keyBy(_.filter(records, ({id}) => _.indexOf(selectedRecords, id) >= 0), 'id'),
      sortBy: service.labels._default,
      sortDir: ASC,
      filters: filters !== PROP_UNAVAILABLE ? filters : {},
    }

    this.next = this.next.bind(this)
    this.previous = this.previous.bind(this)
    this.start = this.start.bind(this)
    this.end = this.end.bind(this)
    this.toggleSelection = this.toggleSelection.bind(this)
    this.clearSelection = this.clearSelection.bind(this)
    this.updateRecordSelection = this.updateRecordSelection.bind(this)
    this.onSelect = this.onSelect.bind(this)
    this.onSelectId = this.onSelectId.bind(this)
    this.onChangeFilter = this.onChangeFilter.bind(this)
    this.clearFilters = this.clearFilters.bind(this)
  }

  componentWillReceiveProps ({reset, records, selectedRecords, clearFilter, toggleClearFilter}) {
    if (selectedRecords === PROP_UNAVAILABLE) {
      if (reset && reset !== this.props.reset) {
        this.setState({
          page: 0,
          selectedRecords: {},
          allSelected: false,
        })
      } else {
        this.refreshSelection(records)
      }
    }
    if (clearFilter) {
      this.setState({filters: {}})
      toggleClearFilter(false)
    }
  }

  refreshSelection (records = this.props.records) {
    const {selectedRecords, didChange} = _.reduce(this.state.selectedRecords, (acc, record, id) => {
      if (records[id]) {
        acc.selectedRecords[id] = records[id]
      } else {
        acc.didChange = true
      }

      return acc
    }, {selectedRecords: {}, didChange: false})
    this.setState({
      selectedRecords,
    }, didChange ? this.onSelect : null)
  }

  getSelectedRecords () {
    const { selectedRecords } = this.props
    if (selectedRecords === PROP_UNAVAILABLE) {
      return this.state.selectedRecords
    }

    return selectedRecords
  }

  clearSelection () {
    this.toggleSelection({clear: true})
  }

  toggleSelection ({clear = false} = {}) {
    const { selectedRecords } = this.props

    if (selectedRecords === PROP_UNAVAILABLE) {
      const allSelected = !this.state.allSelected
      const { selectedRecords } = this.getSelectedRecords()
      let nextSelectedRecords = {}

      if (clear) {
        this.setState({
          selectedRecords: {},
        }, this.onSelect)
      } else if (allSelected) {
        nextSelectedRecords = _.keyBy(this.getRecordsOfPage(), 'id')
        this.setState({
          allSelected,
          selectedRecords: nextSelectedRecords,
        }, this.onSelect)
      } else {
        const currentIds = this.getRecordIds()
        nextSelectedRecords = _.omitBy(selectedRecords, (value, id) => currentIds.indexOf(Number(id)) >= 0)
        this.setState({
          allSelected,
          selectedRecords: nextSelectedRecords,
        }, this.onSelect)
      }
    } else {
      const recordIds = _.map(this.getRecordsOfPage(), ({id}) => id)

      if (clear) {
        this.props.onSelect(false, ...recordIds)
      } else {
        this.props.onSelect(!this.allSelected(), ...recordIds)
      }
    }
  }

  getMax (records = this.props.records) {
    return _.size(records)
  }

  getPage () {
    return this.state.page
  }

  getPerPage () {
    return this.props.perPage
  }

  lastPage () {
    return Math.floor(this.getMax() / this.getPerPage())
  }

  start () {
    this.setState({
      allSelected: false,
      page: 0,
    })
  }

  previous () {
    const page = this.getPage() - 1

    this.setState({
      allSelected: false,
      page: page >= 0 ? page : 0,
    })
  }

  next () {
    const page = this.getPage() + 1
    this.setState({
      allSelected: false,
      page: page < this.lastPage() ? page : this.lastPage(),
    })
  }

  end () {
    this.setState({
      allSelected: false,
      page: this.lastPage(),
    })
  }

  goToPage (page) {
    this.setState({
      page: Number(page),
    })
  }

  getFirstRecordIndex (records = this.props.records) {
    const index = (this.getPage() * this.getPerPage()) + 1

    if (index > this.getMax(records)) {
      return this.getMax(records)
    }

    return index
  }

  getLastRecordIndex (records = this.props.records) {
    const index = (this.getPage() * this.getPerPage()) + this.getPerPage()

    if (index > this.getMax(records)) {
      return this.getMax(records)
    }

    return index
  }

  isSelected ({id}) {
    const { selectedRecords } = this.props

    if (selectedRecords === PROP_UNAVAILABLE) {
      const { allSelected, selectedRecords } = this.state
      return allSelected || selectedRecords.hasOwnProperty(id)
    }

    return _.indexOf(selectedRecords, id) >= 0
  }

  updateRecordSelection (record) {
    const { selectedRecords } = this.props
    if (selectedRecords === PROP_UNAVAILABLE) {
      return (selected) => {
        const { selectedRecords } = this.state
        let nextSelectedRecords = {}

        if (selected) {
          nextSelectedRecords = {
            ...selectedRecords,
            [record.id]: record,
          }
          this.setState({
            selectedRecords: nextSelectedRecords,
          }, this.onSelect)
        } else {
          nextSelectedRecords = _.omit(selectedRecords, record.id)
          this.setState({
            allSelected: false,
            selectedRecords: nextSelectedRecords,
          }, this.onSelect)
        }
      }
    }

    return this.onSelectId
  }

  sortBy (attr) {
    const { sortBy, sortDir } = this.state

    if (attr === sortBy && sortDir === DESC) {
      const { service } = this.props

      this.setState({
        sortBy: service.labels._default,
        sortDir: ASC,
      })
    } else if (attr === sortBy && sortDir === ASC) {
      this.setState({
        sortDir: DESC,
      })
    } else {
      this.setState({
        sortBy: attr,
        sortDir: ASC,
      })
    }
  }

  getFilters () {
    const { filters } = this.props

    if (filters === PROP_UNAVAILABLE) {
      return this.state.filters
    }

    return filters
  }

  hasFilters () {
    return _.some(this.getFilters())
  }

  getSortedRecords () {
    const { service, records, sort } = this.props
    const { sortBy, sortDir } = this.state

    if (typeof sort === 'function') {
      return sort(records, sortBy, sortDir)
    }

    return _.orderBy(records, (record) => {
      if (service.tableSorter) {
        return service.tableSorter(record, sortBy)
      }

      return service.print(record, sortBy)
    }, sortDir)
  }

  getSortedAndFilteredRecords () {
    const { service, filter } = this.props
    const sorted = this.getSortedRecords()

    if (this.hasFilters()) {
      if (typeof filter === 'function') {
        return filter(sorted)
      }

      const filters = this.getFilters()

      return _.filter(sorted, (record) => {
        return !_.some(filters, (filterValue, attr) => {
          const compare = filterValue.replace(/[^0-9,A-z]/g, '').toLowerCase()
          if (!compare) {
            return false
          }

          const value = ('' + service.print(record, attr)).replace(/[^0-9,A-z]/g, '').toLowerCase()
          return value.indexOf(compare) < 0
        })
      })
    }

    return sorted
  }

  getRecords () {
    return this.getSortedAndFilteredRecords()
  }

  getRecordsOfPage (records = this.getRecords()) {
    const indexStart = this.getPage() * this.getPerPage()
    const indexEnd = indexStart + this.getPerPage()
    return records.slice(indexStart, indexEnd)
  }

  getRecordIds () {
    return _.map(this.getRecordsOfPage(), (record) => record.id)
  }

  getActualColumns ({columns, service, mediaQueryMatch} = this.props) {
    if (!mediaQueryMatch) {
      return [{
        attr: service.labels._default,
      }]
    }

    return columns || service.getDefaultColumns()
  }

  getColumns ({columns, service, mediaQueryMatch} = this.props) {
    const tableColumns = this.getActualColumns({columns, service, mediaQueryMatch})
    const numOfColumns = _.size(tableColumns)

    const defaultConfig = {
      flexBase: numOfColumns === 1 ? 'auto' : 100 / (numOfColumns + 1),
      name: '',
      sortable: true,
      filter: true,
    }

    return _.map(tableColumns, (column) => {
      if (typeof column !== 'object') {
        return {
          ...defaultConfig,
          attr: column,
        }
      }

      return {
        ...defaultConfig,
        ...column,
      }
    })
  }

  onSelect () {
    this.props.onSelect(this.state.selectedRecords)
  }

  onSelectId ({id}) {
    this.props.onSelect(id)
  }

  onChangeFilter (attr) {
    const { filters } = this.props

    if (filters === PROP_UNAVAILABLE) {
      return (value) => {
        this.setState({
          focus: attr,
          filters: {
            ...this.getFilters(),
            [attr]: value,
          },
        }, () => {
          if (this.props.onChangeFilter) {
            this.props.onChangeFilter(this.getFilters())
          }
        })
      }
    } else {
      return (value) => {
        const filters2 = {
          ...this.getFilters(),
          [attr]: value,
        }

        this.props.onChangeFilter(filters2)
      }
    }
  }

  isFiltered () {
    return _.reduce(this.getFilters(), (mem, filter) => {
      return mem || filter !== ''
    }, false)
  }

  getTranslatedHoc (attr) {
    const { service } = this.props
    this.translatedHocs = this.translatedHocs || {}

    if (this.translatedHocs[attr]) {
      return this.translatedHocs[attr]
    }

    const translated = translate2(service.labels[attr] || attr, service)
    const InputBox = translated(({translation, ...props}) =>
      <FilterInput
        placeholder={translation} {...props}
      />
    )

    this.translatedHocs[attr] = InputBox

    return InputBox
  }

  renderFilters (tableColumns = this.getColumns()) {
    const { filterFocus } = this.props

    const filters = _.map(tableColumns, ({attr, flexBase, type, filter}) => {
      if (!filter) {
        return null
      }

      const InputBox = this.getTranslatedHoc(attr)

      return (
        <TableCell key={attr} flexBase={flexBase} type={type} style={filterCell()} header>
          <InputBox
            align={type === 'number' ? 'right' : 'left'}
            hidePlaceholder={this.props.hideFilterText}
            // focus={attr === this.state.focus}
            value={this.getFilters()[attr]}
            // onFocus={bind(this)(this.setState, {focus: attr})}
            onChange={this.onChangeFilter(attr)}
          />
        </TableCell>
      )
    })
    const hasFilter = this.isFiltered()
    return (
      <li id={'_filters'} style={filtersInput(hasFilter, filterFocus)}>
        <ul style={{
          ...fonts.font({size: '0.9em', bold: 500}),
          ...flex.flex(),
        }}>
          <TableCell flexBase={'40px'} style={filterCell()} />
          <li style={{
            flex: '1 1 auto',
          }}>
            <ul style={flex.flex()}>{filters}</ul>
          </li>
        </ul>
      </li>
    )
  }

  allSelected () {
    const { selectedRecords } = this.props

    if (selectedRecords !== PROP_UNAVAILABLE) {
      const recordIdsOnPage = _.map(this.getRecordsOfPage(), ({id}) => id)
      return _.every(recordIdsOnPage, (id) => _.indexOf(selectedRecords, id) >= 0)
    }

    return this.state.allSelected
  }

  renderSelectAllBox () {
    if (!this.props.hideCheckBox) {
      return (
        <CheckBox checked={this.allSelected()} onClick={this.toggleSelection} />
      )
    }
  }

  renderHeaders (tableColumns = this.getColumns(), records = this.getRecords()) {
    const { service, hideSelectAll } = this.props
    const { sortBy, sortDir } = this.state

    const checkBox = !hideSelectAll && _.size(records) ? this.renderSelectAllBox() : null

    const headers = _.map(tableColumns, ({attr, flexBase, type}) => {
      let postfix
      if (service.unitTypes[attr]) {
        postfix = (
          <span style={{color: colors.lightGrey()}}>
            {`(${service.getUnitsInUseLabel(attr)})`}
          </span>
        )
      }

      let sortIcon
      if (sortBy === attr) {
        sortIcon = sortDir === DESC ? <DownIcon size={14} /> : <UpIcon size={14} />
      }

      const onSort = this.sortBy.bind(this, attr)

      return (
        <TableCell key={attr}
          flexBase={flexBase}
          type={type}
          header
          style={{cursor: 'pointer'}}
          onClick={onSort}>
          {translate(service.labels[attr] || attr, service)} {postfix} {sortIcon}
        </TableCell>
      )
    })

    return (
      <li id={'_headers'}>
        <ul style={{
          ...fonts.font({size: '0.9em', bold: 500}),
          ...flex.flex(),
        }}>
          <TableCell flexBase={'40px'}>
            {checkBox}
          </TableCell>
          <li style={{
            flex: '1 1 auto',
          }}>
            <ul style={flex.flex()}>{headers}</ul>
          </li>
        </ul>
      </li>
    )
  }

  renderPaginator (records = this.getRecords()) {
    const { page } = this.state
    const { perPage } = this.props
    const enableButton = perPage < records.length
    const paginateBtnStyle = enableButton ? {
      padding: 15,
      cursor: 'pointer',
    } : {
      padding: 15,
      opacity: 0.65,
      cursor: 'not-allowed',
    }
    const buttonColor = enableButton ? '#333' : colors.DISABLE_BUTTON_GRAY
    return (
      <div style={{
        flex: '0 0 auto',
      }}>
        <ul style={flex.flex({
          position: 'relative',
          width: '100%',
          backgroundColor: '#fff',
          alignItems: 'center',
          justifyContent: 'space-around',
          minHeight: 54,
          ...shadow.box({x: 0, y: -2, blur: 2, color: 0.1}),
        })}>
          <li onClick={enableButton && this.start}
            style={page === 0 ? {opacity: 0.50, cursor: 'not-allowed'} : paginateBtnStyle}>
            <NavFirstIcon size={24} color={page === 0 ? colors.DISABLE_BUTTON_GRAY : buttonColor} />
          </li>
          <li onClick={enableButton && this.previous}
            style={page === 0 ? {opacity: 0.50, cursor: 'not-allowed'} : paginateBtnStyle}>
            <NavBeforeIcon size={24} color={page === 0 ? colors.DISABLE_BUTTON_GRAY : buttonColor} />
          </li>
          <li style={{color: buttonColor}}>
            {this.getFirstRecordIndex(records)} - {this.getLastRecordIndex(records)} of {this.getMax(records)}
          </li>
          <li onClick={enableButton && this.next}
            style={page === this.lastPage() ? {opacity: 0.50, cursor: 'not-allowed'} : paginateBtnStyle}>
            <NavAfterIcon size={24} color={page === this.lastPage() ? colors.DISABLE_BUTTON_GRAY : buttonColor} />
          </li>
          <li onClick={enableButton && this.end}
            style={page === this.lastPage() ? {opacity: 0.50, cursor: 'not-allowed'} : paginateBtnStyle}>
            <NavLastIcon size={24} color={page === this.lastPage() ? colors.DISABLE_BUTTON_GRAY : buttonColor} />
          </li>
        </ul>
      </div>
    )
  }

  renderRows (tableColumns = this.getColumns(), records = this.getRecords()) {
    const { printer, service, selectedRecords } = this.props
    const onSelectReturnRecord = selectedRecords !== PROP_UNAVAILABLE
    return _.map(records, (record) => {
      if (record) {
        return (
          <TableRow
            key={record.id}
            record={record}
            service={service}
            printer={printer}
            selected={this.isSelected(record)}
            columns={tableColumns}
            onSelectReturnRecord={onSelectReturnRecord}
            onSelect={this.updateRecordSelection(record)}
            hideCheckBox={this.props.hideCheckBox}
          />
        )
      }

      return null
    })
  }

  getHeaderRowStyle () {
    return {
      flex: '1 1 auto',
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'flex-end',
    }
  }

  clearFilters () {
    const { filters } = this.props

    if (filters === PROP_UNAVAILABLE) {
      this.setState({filters: {}})
      this.props.toggleClearFilter(true)
    } else {
      this.props.onChangeFilter({})
    }
  }

  renderClearFilters () {
    if (this.isFiltered()) {
      return (
        <InfoButton onClick={this.clearFilters}>
          {translate('clearFilterText', messages)}
        </InfoButton>
      )
    }
  }

  renderSelectionCount () {
    const { hideSelectAll } = this.props
    const selectedRecords = !hideSelectAll ? this.getSelectedRecords() : []
    const count = !hideSelectAll && _.size(selectedRecords)

    if (count) {
      return (
        <InfoButton onClick={this.clearSelection}>
          <span>{count} records selected</span>
        </InfoButton>
      )
    }

    return null
  }

  renderHeaderRow () {
    const { children, hasHeaderRow } = this.props

    if (hasHeaderRow) {
      return (
        <div style={{
          color: colors.secondary(),
          display: 'flex',
          backgroundColor: colors.secondary(0.1),
          padding: '0 15px',
          height: 50,
          alignItems: 'center',
          flex: '0 0 50px',
        }}>
          {this.renderSelectionCount()}
          {this.renderClearFilters()}
          <div style={this.props.headerRowStyle || this.getHeaderRowStyle()}>
            {children}
          </div>
        </div>
      )
    }
  }

  render () {
    const { service, tableStyle } = this.props
    const records = this.getRecords()
    const pageRecords = this.getRecordsOfPage(records)
    const tableColumns = this.getColumns()

    const headers = this.renderHeaders(tableColumns, pageRecords)
    const filters = this.renderFilters(tableColumns, records)
    const rows = this.renderRows(tableColumns, pageRecords)
    const paginator = this.renderPaginator(records)
    this.props.onRender(records)
    return (
      <div data-table={service.plural()} style={{
        width: '100%',
        backgroundColor: '#fff',
        ...fonts.font({size: 14, color: colors.grey()}),
        display: 'flex',
        flexDirection: 'column',
        flex: '1 1 auto',
        ...tableStyle,
      }}>
        {this.renderHeaderRow()}
        <ol style={{
          width: '100%',
          height: '100%',
          flex: '1 1 auto',
          backgroundColor: '#fff',
          display: 'flex',
          flexDirection: 'column',
        }}>
          <div style={{
            flex: '0 0 auto',
          }}>
            {headers}
            {filters}
          </div>
          <div style={{
            flex: '1 1 auto',
            overflowY: 'auto',
          }}>
            {rows}
          </div>
        </ol>
        {paginator}
      </div>
    )
  }
}

DataTable.propTypes = {
  records: PropTypes.object,
  service: PropTypes.object,
  printer: PropTypes.object,
  onSelect: PropTypes.func,
  reset: PropTypes.any,
  hideFilterText: PropTypes.bool,
  hideSelectAll: PropTypes.bool,
  hideCheckBox: PropTypes.bool,
  mediaQueryMatch: PropTypes.bool,
  columns: PropTypes.array,
  children: PropTypes.oneOfType([PropTypes.element, PropTypes.arrayOf(PropTypes.element)]),
  onRender: PropTypes.func,
  selectedRecords: PropTypes.oneOfType([
    PropTypes.array,
    PropTypes.oneOf([PROP_UNAVAILABLE]),
  ]),
  filters: PropTypes.oneOfType([
    PropTypes.object,
    PropTypes.oneOf([PROP_UNAVAILABLE]),
  ]),
  headerRowStyle: PropTypes.object,
  onChangeFilter: PropTypes.func,
  toggleClearFilter: PropTypes.func,
  filterFocus: PropTypes.bool,
  tableStyle: PropTypes.object,
  filterText: PropTypes.object,
  hasHeaderRow: PropTypes.bool,
  perPage: PropTypes.number,
  filter: PropTypes.func,
  sort: PropTypes.func,
}

DataTable.defaultProps = {
  records: [],
  service: createServices(),
  printer: {},
  components: {},
  onSelect: () => {},
  reset: false,
  mediaQueryMatch: false,
  onRender: () => {},
  selectedRecords: PROP_UNAVAILABLE,
  filters: PROP_UNAVAILABLE,
  filterFocus: false,
  tableStyle: {},
  filterText: translate('filterText', messages),
  toggleClearFilter: () => {},
  hasHeaderRow: true,
  perPage: 15,
}

export default responsive()(DataTable)
