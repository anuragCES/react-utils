import React, { Component, PropTypes } from 'react'
import { map } from 'lodash'
import { flex, colors } from 'styles'
import { tableRow } from './styles'
import TableCell from './TableCell'
import hover from 'hocs/mouse'
import { CheckBox } from 'components/forms'
import { CheckIcon } from 'components/icons'

class TableRow extends Component {
  constructor (props) {
    super()

    this.toggleSelection = this.toggleSelection.bind(this)
  }

  getDefaultColumns () {
    return this.props.service.getDefaultColumns()
  }

  toggleSelection () {
    const { onSelectReturnRecord, record } = this.props

    this.props.onSelect(onSelectReturnRecord ? record : !this.props.selected)
  }

  render () {
    const { columns, service, record, selected, printer, hover } = this.props
    const print = service.print.bind(service)

    const cells = map(columns, ({attr, flexBase, type}) => {
      const value = print(record, attr)
      let el = value

      if (printer[attr] && typeof printer[attr] === 'function') {
        el = printer[attr](record, attr, value)
      } else if (type === 'boolean') {
        el = value ? <CheckIcon color={'rgb(117, 117, 117)'} /> : null
      }

      return (
        <TableCell key={`${record.id}_${attr}`} flexBase={flexBase} type={type}>
          {el}
        </TableCell>
      )
    })

    return (
      <ul data-record={record.id} style={tableRow({hover, selected})} onClick={this.toggleSelection}>
        <TableCell key={'_' + record.id} flexBase={'40px'}>
          { this.props.hideCheckBox ? null
            : <CheckBox
              checked={selected}
              onClick={this.toggleSelection}
              colorChecked={colors.primary()}
              />
          }
        </TableCell>
        <li style={{
          flex: '1 1 auto',
        }}>
          <ul style={flex.flex()}>{cells}</ul>
        </li>
      </ul>
    )
  }
}

TableRow.propTypes = {
  record: PropTypes.object.isRequired,
  service: PropTypes.object.isRequired,
  printer: PropTypes.object,
  hover: PropTypes.bool.isRequired,
  selected: PropTypes.bool,
  onSelect: PropTypes.func,
  columns: PropTypes.array.isRequired,
  onSelectReturnRecord: PropTypes.bool,
  hideCheckBox: PropTypes.bool,
}

TableRow.defaultProps = {
  printer: {},
  selected: false,
  onSelect: () => {},
  onSelectReturnRecord: false,
}

// TODO: hover seems to be undefined when running test Home.spec.js
// TableRow is not being used in views/dashboard/Home.js as far as I can TableCell
// It works perfectly fine when running npm start
const newHover = hover || function (View) { return View }
export default newHover(TableRow)
