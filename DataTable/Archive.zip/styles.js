import { colors, shadow, flex } from 'styles'

const tableRowBackground = ({hover, selected}) => {
  if (selected) {
    return colors.primary(hover ? 0.2 : 0.1)
  } else if (hover) {
    return colors.blue(0.1)
  }

  return 'transparent'
}

export const tableRow = ({hover, selected}) => ({
  ...flex.flex(),
  borderBottom: '1px solid #E0E0E0',
  transition: 'background-color 0.3s linear, border-color 0.3s linear',
  backgroundColor: tableRowBackground({hover, selected}),
})

export const tableCell = ({flexBase = 20, type, style = {}}) => ({
  ...flex.item({
    grow: flexBase === 'auto' ? 1 : 0,
    shrink: flexBase === 'auto' ? 1 : 0,
    base: flexBase,
    marginRight: 0,
  }),
  paddingLeft: type === 'number' ? 0 : 7,
  paddingRight: type === 'number' ? 14 : 7,
  display: 'flex',
  alignItems: 'center',
  textAlign: type === 'number' ? 'right' : 'left',
  minHeight: 48,
  overflow: 'hidden',
  lineHeight: '150%',
  ...style,
})

export const filterCell = () => ({
  paddingLeft: 0,
  paddingRight: 0,
  display: 'flex',
  alignItems: 'center',
  textAlign: 'left',
  minHeight: 'initial',
  overflow: 'hidden',
})

export const filtersInput = (hasContent, focused) => {
  const color = hasContent ? colors.primary(0.5) : focused ? colors.blue(0.5) : colors.grey(0.8)
  return ({
    backgroundColor: '#F9F9F9',
    ...shadow.box({x: 0, y: 0, blur: 3, color}),
    transition: 'box-shadow 0.2s linear',
  })
}

export const filterRemoveContainerStyle = {
  display: 'flex',
  cursor: 'pointer',
  alignItems: 'center',
  marginLeft: '5px',
  color: colors.secondary(),
  backgroundColor: colors.white(),
  padding: '5px 7px',
  borderRadius: 2,
  ...shadow.box({x: 1, y: 1, blur: 2}),
}

export const filterRemoveStyle = {
  cursor: 'pointer',
  marginLeft: '5px',
}
