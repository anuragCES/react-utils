import React, { PropTypes } from 'react'

// Components
import CloseIcon from 'components/icons/close'

// Styles
import { colors, shadow } from 'styles'

// Local Styles
const style = {
  display: 'flex',
  cursor: 'pointer',
  alignItems: 'center',
  marginLeft: '5px',
  color: colors.secondary(),
  backgroundColor: colors.white(),
  borderRadius: 2,
  ...shadow.box({x: 1, y: 1, blur: 2}),
}

const iconDivStyle = {
  padding: '5px 7px',
  backgroundColor: colors.primary(),
}

const labelDivStyle = {
  padding: '5px 7px',
  backgroundColor: colors.white(),
}

export default function InfoButton ({onClick, Icon = CloseIcon, children, size = 16, color = colors.white()}) {
  return (
    <div style={style} onClick={onClick}>
      <div style={iconDivStyle}>
        <Icon size={size} color={color} />
      </div>
      <div style={labelDivStyle}>
        {children}
      </div>
    </div>
  )
}

InfoButton.propTypes = {
  onClick: PropTypes.func.isRequired,
  Icon: PropTypes.func,
  children: PropTypes.node.isRequired,
  size: PropTypes.number,
  color: PropTypes.string,
}
